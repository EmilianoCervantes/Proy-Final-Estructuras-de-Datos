package edu.itesm.mx.proyecto;


import java.util.*;

import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.graph.*;

public class Grafo extends HashMap<String, 
CircularDoubleLinkedList<String>>{

	public Grafo(){
		super();
	}

	
	
}
